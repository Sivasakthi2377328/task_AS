import logo from './logo.svg';
import './App.css';
import  './Css/Login.css'
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from './Login';
import Home from './Home';

function App() {
  return (
   
    <BrowserRouter>
    <Routes>
      <Route path="/" element={<Login />}></Route>

  <Route path='/home' element={<Home/>}></Route>
      
     
    </Routes>
  </BrowserRouter>
  );
}

export default App;
