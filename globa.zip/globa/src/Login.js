import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Form = ({ handleLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const onSubmit = (e) => {
    e.preventDefault();
    handleLogin(username, password);
  };

  return (
    <form className='loginform' onSubmit={onSubmit}>
      <p className='loginheader'>Login</p>
      <label>Username</label>
      <br />
      <input
        required
        type='text'
        name='username'
        value={username}
        onChange={(e) => setUsername(e.target.value)}
      />
      <br />
      <label>Password</label>
      <br />
      <input
        required
        type='password'
        name='password'
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <br />
      <button type='submit'>Sign in</button>
    </form>
  );
};

const Login = () => {
  const navigate = useNavigate();

  const handleLogin = async (username, password) => {
    const response = await fetch('http://localhost:3000/login', { 
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ username, password }),
    });

    const result = await response.json();
    console.log(result);

    if (response.ok) {
      navigate('/home');
    } else {
      alert('Login failed: ' + result.responsemessage);
    }
  };

  return (
    <div className='main'>
      <Form handleLogin={handleLogin} />
    </div>
  );
};

export default Login;
